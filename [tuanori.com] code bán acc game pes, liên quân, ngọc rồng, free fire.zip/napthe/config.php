<?php
	$url = 'http://sys.napthenhanh.com/api/charging-wcb'; 
	$partner_id = '0189371561'; 
	$partner_key = 'a44b6c0ecb056f70193da543bc55752f'; 
?>
<?php require('../TMQ/function.php'); ?>
<?php require('../TMQ/head.php'); ?>
<div class="c-layout-page">
<?php require('head.php'); ?>
<div class="c-layout-sidebar-content ">
				<!-- BEGIN: PAGE CONTENT -->
				<!-- BEGIN: CONTENT/SHOPS/SHOP-CUSTOMER-DASHBOARD-1 -->
				<div class="c-content-title-1">
					<h3 class="c-font-uppercase c-font-bold">Nạp thẻ chậm</h3>
					<div class="c-line-left"></div>
				</div>









</div>	</div></div></div></div>
<?php require('../TMQ/end.php'); ?>
<?
/*
#########################################################
#               Code Write By Duong IT 911              #
#              Email: svpv.hotro@gmail.com              #
#            Phone: 01693067818 - 01698330911           #
#            Vui Lòng Tôn Trọng Quyền Tác Giả           #
#########################################################
*/
$fb = new Facebook\Facebook ([
  'app_id' => '944886685689961', // Id app
  'app_secret' => '6300e1478c4537b3f0f418c0fe9995bb', // Mã bảo mật app
  'default_graph_version' => 'v3.0', //Giữ Nguyên
  ]);
$domain = 'https://demo2.tmquang.xyz/login/'; //Domain có / ở cuối
?>